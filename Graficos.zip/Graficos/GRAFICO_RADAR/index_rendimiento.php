<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gráfico de Radar - Subgéneros de Libros</title>
    <!-- Incluir Chart.js desde CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div style="width: 80%; margin: auto;">
        <canvas id="graficoRadar"></canvas>
    </div>

    <script>
        // PHP para obtener datos de la base de datos y convertirlos a JSON
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "libreria";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $database);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consulta SQL para obtener los datos de rendimiento de los subgéneros
        $sql = "SELECT s.nombre_subgenero AS subgenero, COUNT(l.ISBN) AS cantidad_libros
                FROM libros l
                JOIN subgenero s ON l.id_subgenero = s.id_subgenero
                GROUP BY l.id_subgenero
                ORDER BY cantidad_libros DESC";

        $result = $conn->query($sql);

        // Array para almacenar los resultados
        $datos = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $datos[] = $row;
            }
        }

        // Cerrar conexión
        $conn->close();

        // Convertir datos a formato JSON
        $json_datos = json_encode($datos);
        echo "var datos = " . $json_datos . ";";
        ?>

        // Preparar datos para el gráfico de radar
        var nombresSubgeneros = [];
        var cantidadLibros = [];

        datos.forEach(function(item) {
            nombresSubgeneros.push(item.subgenero);
            cantidadLibros.push(item.cantidad_libros);
        });

        // Configuración del gráfico de radar
        var ctx = document.getElementById('graficoRadar').getContext('2d');
        var myRadarChart = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: nombresSubgeneros,
                datasets: [{
                    label: 'Cantidad de Libros por Subgénero elegidos por los usuarios',
                    data: cantidadLibros,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)', // Color de fondo
                    borderColor: 'rgba(54, 162, 235, 1)', // Color del borde
                    borderWidth: 1
                }]
            },
            options: {
                scale: {
                    ticks: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
