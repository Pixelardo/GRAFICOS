<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'libreria';
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($mysqli->connect_errno)
    die('No se puede conectar: ' . $mysqli->connect_error);

// Consulta SQL para verificar si hay ventas en el mes actual
$check_sql = 'SELECT COUNT(*) AS numVentas FROM ventas WHERE DATE_FORMAT(fecha_venta, "%Y-%m") = DATE_FORMAT(CURRENT_DATE, "%Y-%m")';
$check_resultado = $mysqli->query($check_sql);

if (!$check_resultado)
    die('No se pudo realizar la consulta: ' . $mysqli->error);

$check_row = $check_resultado->fetch_assoc();
$numVentas = $check_row['numVentas'] ?? 0;

// Si no hay ventas en el mes actual, insertamos datos de ejemplo
if ($numVentas == 0) {
    $insert_sql = "INSERT INTO ventas (`ISBN`, `id_usuario`, `id_vendedor`, `cantidad_libros`, `fecha_venta`) VALUES
                   ('9780545010221', 1, 1, 10, '2024-06-01 08:00:00'),
                   ('9789561129528', 2, 2, 15, '2024-06-05 12:30:00'),
                   ('9789876123549', 3, 3, 30, '2024-06-10 14:00:00')";
    if (!$mysqli->query($insert_sql))
        die('No se pudo insertar datos de ejemplo: ' . $mysqli->error);
}

// Consulta SQL para obtener el total de libros vendidos en el mes actual
$sql = 'SELECT SUM(cantidad_libros) AS TotalLibrosVendidos FROM ventas WHERE DATE_FORMAT(fecha_venta, "%Y-%m") = DATE_FORMAT(CURRENT_DATE, "%Y-%m")';
$resultado = $mysqli->query($sql);

if (!$resultado)
    die('No se pudo realizar la consulta: ' . $mysqli->error);

$row = $resultado->fetch_assoc();
$totalLibrosVendidos = $row['TotalLibrosVendidos'] ?? 0;

$resultado->free();
$mysqli->close();
?>


