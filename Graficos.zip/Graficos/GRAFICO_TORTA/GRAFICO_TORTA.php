<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'libreria';
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if($mysqli->connect_errno) {
    die('No se puede conectar: ' . $mysqli->connect_error);
}

$sql1 = 'SELECT subgenero.nombre_subgenero AS Subgenero, SUM(ventas.cantidad_libros * libros.precio) AS TotalVentas
         FROM libros
         JOIN subgenero ON libros.id_subgenero = subgenero.id_subgenero
         JOIN ventas ON libros.ISBN = ventas.ISBN
         GROUP BY subgenero.nombre_subgenero';

$resultado = $mysqli->query($sql1);

if(!$resultado) {
    die('No se pudo realizar la consulta: ' . $mysqli->error);
}

$datos1 = "";

while($row = $resultado->fetch_assoc()) {
    $datos1 .= "['" . $row['Subgenero'] . "'," . $row['TotalVentas'] . "],";
}

$datos1 = rtrim($datos1,",");

$resultado->free();
$mysqli->close();
?>

<html>
<head>
    <!-- Load the AJAX API -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

        // Load the Visualization API and the corechart package.
        google.charts.load('current', {'packages':['corechart']});

        // Set a callback to run when the Google Visualization API is loaded.
        google.charts.setOnLoadCallback(drawChart);

        // Callback that creates and populates a data table,
        // instantiates the pie chart, passes in the data and
        // draws it.
        function drawChart() {

            // Create the data table for Pie Chart.
            var dataPie = new google.visualization.DataTable();
            dataPie.addColumn('string', 'Subgenero');
            dataPie.addColumn('number', 'TotalVentas');
            dataPie.addRows([<?php echo $datos1; ?>]);

            // Set chart options for Pie Chart.
            var optionsPie = {
                'title': 'Total de Ventas por SubgÃ©nero',
                'width': 800,
                'height': 600
            };

            // Instantiate and draw the Pie chart.
            var chartPie = new google.visualization.PieChart(document.getElementById('chart_div_pie'));
            chartPie.draw(dataPie, optionsPie);
        }
    </script>
</head>

<body>
    <!-- Div that will hold the pie chart -->
    <div id="chart_div_pie"></div>
</body>
</html>