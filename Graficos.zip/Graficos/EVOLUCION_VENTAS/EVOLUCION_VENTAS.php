<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'libreria';
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if($mysqli->connect_errno)
    die('No se puede conectar: ' . $mysqli->connect_error);

// Consulta SQL para la evolución de las ventas por mes
$sql = 'SELECT DATE_FORMAT(fecha_venta, "%Y-%m") AS Mes, SUM(cantidad_libros) AS TotalLibrosVendidos FROM ventas GROUP BY Mes ORDER BY Mes';
$resultado = $mysqli->query($sql);

if(!$resultado)
    die('No se pudo realizar la consulta: ' . $mysqli->error);

$datos = "";
$meses = array(
    "01" => "Ene",
    "02" => "Feb",
    "03" => "Mar",
    "04" => "Abr",
    "05" => "May",
    "06" => "Jun",
    "07" => "Jul",
    "08" => "Ago",
    "09" => "Sep",
    "10" => "Oct",
    "11" => "Nov",
    "12" => "Dic"
);

while($row = $resultado->fetch_assoc()) {
    $ano_mes = explode("-", $row['Mes']);
    $mes_letras = $meses[$ano_mes[1]] . " " . $ano_mes[0];
    $datos .=  "['" . $mes_letras . "'," . $row['TotalLibrosVendidos'] . "],";
}

$datos = rtrim($datos,",");

$resultado->free();
$mysqli->close();
?>

<html>
  <head>
    <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {'packages':['corechart']});

      // Set a callback to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table,
      // instantiates the line chart, passes in the data and
      // draws it.
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Mes');
        data.addColumn('number', 'Total de Libros Vendidos');
        data.addRows([<?php echo $datos; ?>]);

        // Set chart options
        var options = {
          'title': 'Evolución de las Ventas',
          'width': 800,  // Aumenta el ancho del gráfico
          'height': 500, // Aumenta la altura del gráfico
          'fontSize': 16, // Aumenta el tamaño de la fuente general
          'colors': ['#FF0000'], // Cambia el color del gráfico a rojo
          'pointSize': 5, // Tamaño de los puntos en las líneas del gráfico
          'hAxis': {
            'textStyle': {
              'fontSize': 14 // Aumenta el tamaño de la fuente del eje horizontal
            }
          },
          'vAxis': {
            'title': 'Cantidad de Libros',
            'titleTextStyle': {
              'fontSize': 18,  // Aumenta el tamaño de la fuente del título del eje vertical
              'italic': false
            },
            'textStyle': {
              'fontSize': 14 // Aumenta el tamaño de la fuente del eje vertical
            }
          },
          'titleTextStyle': {
            'fontSize': 20 // Aumenta el tamaño de la fuente del título del gráfico
          }
        };

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
  </head>

  <body>
    <!--Div that will hold the line chart-->
    <div id="chart_div"></div>
  </body>
</html>
