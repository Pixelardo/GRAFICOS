<?php
// Configurar la conexión a la base de datos (ajustar según tu entorno)
$servername = "localhost";
$username = "root";
$password = "";
$database = "libreria";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el valor de N desde la petición GET y asegurarse que sea un número entero válido
$n = isset($_GET['n']) ? intval($_GET['n']) : 10; // Valor predeterminado es 10 si no se especifica

// Validar que $n sea un número válido y mayor que cero
if ($n <= 0) {
    $conn->close();
    die("El valor de N debe ser un número entero mayor que cero.");
}

// Consulta SQL para obtener los top N vendedores que más ventas han realizado
$sql = "SELECT vendedores.nombre_vendedor, COUNT(*) AS total_ventas
        FROM ventas
        JOIN vendedores ON ventas.id_vendedor = vendedores.id_vendedor
        GROUP BY ventas.id_vendedor
        ORDER BY total_ventas DESC
        LIMIT $n";

$result = $conn->query($sql);

// Array para almacenar los resultados
$top_vendedores = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $top_vendedores[] = $row;
    }
}

// Cerrar conexión
$conn->close();

// Devolver los resultados como JSON
header('Content-Type: application/json');
echo json_encode($top_vendedores);
?>
