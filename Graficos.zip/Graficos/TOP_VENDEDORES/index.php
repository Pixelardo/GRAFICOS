<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Top N de Vendedores que más han Vendido</title>
<style>
    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
</style>
</head>
<body>

<h2>Top N de Vendedores que más han Vendido</h2>

<!-- Select desplegable para elegir el top N -->
<label for="nVendedores">Mostrar top:</label>
<select id="nVendedores" name="nVendedores" onchange="actualizarTabla()">
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
    <option value="8">8</option>
    <option value="9">9</option>
    <option value="10" selected>10</option>
</select>

<table id="tablaVendedores">
    <thead>
        <tr>
            <th>Posición</th>
            <th>Nombre Vendedor</th>
            <th>Total Ventas</th>
        </tr>
    </thead>
    <tbody id="cuerpoTabla">
        <!-- Aquí se llenará dinámicamente con JavaScript -->
    </tbody>
</table>

<script>
// Función para inicializar la tabla con los datos completos al cargar la página
function inicializarTablaCompleta() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(this.responseText);
            var cuerpoTabla = document.getElementById('cuerpoTabla');
            cuerpoTabla.innerHTML = ''; // Limpiar el contenido actual de la tabla
            for (var i = 0; i < data.length; i++) {
                var fila = '<tr>';
                fila += '<td>' + (i + 1) + '</td>'; // Posición
                fila += '<td>' + data[i].nombre_vendedor + '</td>'; // Nombre Vendedor
                fila += '<td>' + data[i].total_ventas + '</td>'; // Total Ventas
                fila += '</tr>';
                cuerpoTabla.innerHTML += fila;
            }
        }
    };
    xhttp.open("GET", "obtener_top_vendedores.php?n=10", true); // Obtener los top 10 por defecto
    xhttp.send();
}

// Función para actualizar la tabla al cambiar el valor del select
function actualizarTabla() {
    var n = document.getElementById('nVendedores').value;

    // Hacer una petición AJAX para obtener los datos actualizados
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(this.responseText);
            var cuerpoTabla = document.getElementById('cuerpoTabla');
            cuerpoTabla.innerHTML = ''; // Limpiar el contenido actual de la tabla
            for (var i = 0; i < data.length && i < n; i++) {
                var fila = '<tr>';
                fila += '<td>' + (i + 1) + '</td>'; // Posición
                fila += '<td>' + data[i].nombre_vendedor + '</td>'; // Nombre Vendedor
                fila += '<td>' + data[i].total_ventas + '</td>'; // Total Ventas
                fila += '</tr>';
                cuerpoTabla.innerHTML += fila;
            }
        }
    };
    xhttp.open("GET", "obtener_top_vendedores.php?n=" + n, true);
    xhttp.send();
}

// Llamar a la función inicialmente para mostrar el top completo
document.addEventListener("DOMContentLoaded", inicializarTablaCompleta);

</script>

</body>
</html>
