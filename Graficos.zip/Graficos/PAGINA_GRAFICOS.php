<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gráficos Combinados</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 50%;
            margin: 5px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 5px solid #ddd;
            padding: 9px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .chart-container {
            width: 40%;
            margin: auto;
        }
        #graficoRadar {
            width: 100%;
            height: auto;
        }
        #gauge_div {
            width: 200px;
            height: 200px;
            margin: 20px auto;
        }
        .titulo-grafico {
            text-align: center;
        }
    </style>
    <!-- Incluir Google Charts -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <!-- Incluir Chart.js para el gráfico de radar -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

        

    <h2>Top N de Vendedores que más han Vendido</h2>
    <!-- Select desplegable para elegir el top N -->
    <label for="nVendedores">Mostrar top:</label>
    <select id="nVendedores" name="nVendedores" onchange="actualizarTabla()">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10" selected>10</option>
    </select>

    <table id="tablaVendedores">
        <thead>
            <tr>
                <th>Posición</th>
                <th>Nombre Vendedor</th>
                <th>Total Ventas</th>
            </tr>
        </thead>
        <tbody id="cuerpoTabla">
            <!-- Aquí se llenará dinámicamente con JavaScript -->
        </tbody>
    </table>

        

    <!-- Gráfico de Radar - Subgéneros de Libros -->
    <h2 class="titulo-grafico">Gráfico de Radar - Subgéneros de Libros</h2>
    <div class="chart-container">
        <canvas id="graficoRadar"></canvas>
    </div>

    <!-- Gráfico de Gauge - Total de Libros Vendidos -->
    <h2 class="titulo-grafico">Gráfico de Gauge - Total de Libros Vendidos</h2>
    <div id="gauge_div" class="titulo-grafico"></div>

    <!-- Gráfico de Evolución de Ventas por Mes -->
    <h2 class="titulo-grafico">Evolución de Ventas por Mes</h2>
    <div class="chart-container">
        <!-- PHP para obtener datos de la base de datos y convertirlos a JSON -->
        <?php
        $dbhost = 'localhost';
        $dbuser = 'root';
        $dbpass = '';
        $dbname = 'libreria';
        $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

        if($mysqli->connect_errno)
            die('No se puede conectar: ' . $mysqli->connect_error);

        // Consulta SQL para la evolución de las ventas por mes
        $sql = 'SELECT DATE_FORMAT(fecha_venta, "%Y-%m") AS Mes, SUM(cantidad_libros) AS TotalLibrosVendidos FROM ventas GROUP BY Mes ORDER BY Mes';
        $resultado = $mysqli->query($sql);

        if(!$resultado)
            die('No se pudo realizar la consulta: ' . $mysqli->error);

        $datos = "";
        $meses = array(
            "01" => "Ene",
            "02" => "Feb",
            "03" => "Mar",
            "04" => "Abr",
            "05" => "May",
            "06" => "Jun",
            "07" => "Jul",
            "08" => "Ago",
            "09" => "Sep",
            "10" => "Oct",
            "11" => "Nov",
            "12" => "Dic"
        );

        while($row = $resultado->fetch_assoc()) {
            $ano_mes = explode("-", $row['Mes']);
            $mes_letras = $meses[$ano_mes[1]] . " " . $ano_mes[0];
            $datos .=  "['" . $mes_letras . "'," . $row['TotalLibrosVendidos'] . "],";
        }

        $datos = rtrim($datos,",");

        $resultado->free();
        $mysqli->close();
        ?>

        <!-- Dibuja el gráfico de evolución de ventas -->
        <div id="chart_div"></div>
        <script type="text/javascript">
            // Load the Visualization API and the corechart package.
            google.charts.load('current', {'packages':['corechart']});

            // Set a callback to run when the Google Visualization API is loaded.
            google.charts.setOnLoadCallback(drawChart);

            // Callback that creates and populates a data table,
            // instantiates the line chart, passes in the data and
            // draws it.
            function drawChart() {

                // Create the data table.
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'Mes');
                data.addColumn('number', 'Total de Libros Vendidos');
                data.addRows([<?php echo $datos; ?>]);

                // Set chart options
                var options = {
                    'title': 'Evolución de las Ventas',
                    'width': 800,  // Aumenta el ancho del gráfico
                    'height': 500, // Aumenta la altura del gráfico
                    'fontSize': 16, // Aumenta el tamaño de la fuente general
                    'colors': ['#FF0000'], // Cambia el color del gráfico a rojo
                    'pointSize': 5, // Tamaño de los puntos en las líneas del gráfico
                    'hAxis': {
                        'textStyle': {
                            'fontSize': 14 // Aumenta el tamaño de la fuente del eje horizontal
                        }
                    },
                    'vAxis': {
                        'title': 'Cantidad de Libros',
                        'titleTextStyle': {
                            'fontSize': 18,  // Aumenta el tamaño de la fuente del título del eje vertical
                            'italic': false
                        },
                        'textStyle': {
                            'fontSize': 14 // Aumenta el tamaño de la fuente del eje vertical
                        }
                    },
                    'titleTextStyle': {
                        'fontSize': 20 // Aumenta el tamaño de la fuente del título del gráfico
                    }
                };

                // Instantiate and draw our chart, passing in some options.
                var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
                chart.draw(data, options);
            }
        </script>
    </div>

    <!-- Gráfico de Barras Apiladas - Ventas por Subgénero -->
    <h2 class="titulo-grafico">Gráfico de Barras Apiladas - Ventas por Subgénero</h2>
    <div class="chart-container">
        <?php
        // Configuración de la conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "libreria";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consulta SQL para obtener las ventas por mes y subgénero
        $sql = 'SELECT 
                    DATE_FORMAT(ventas.fecha_venta, "%Y-%m") AS Mes, 
                    subgenero.nombre_subgenero AS Subgenero, 
                    SUM(ventas.cantidad_libros * libros.precio) AS TotalVentas
                FROM 
                    ventas
                JOIN 
                    libros ON ventas.ISBN = libros.ISBN
                JOIN 
                    subgenero ON libros.id_subgenero = subgenero.id_subgenero
                GROUP BY 
                    Mes, Subgenero
                ORDER BY 
                    Mes, Subgenero';

        $result = $conn->query($sql);

        if (!$result) {
            die('Consulta fallida: ' . $conn->error);
        }

        // Arreglos para almacenar los datos
        $ventas_por_mes_subgenero = [];
        $subgeneros = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $mes = $row['Mes'];
                $subgenero = $row['Subgenero'];
                $totalVentas = (float)$row['TotalVentas'];

                if (!isset($ventas_por_mes_subgenero[$mes])) {
                    $ventas_por_mes_subgenero[$mes] = [];
                }

                $ventas_por_mes_subgenero[$mes][$subgenero] = $totalVentas;

                if (!in_array($subgenero, $subgeneros)) {
                    $subgeneros[] = $subgenero;
                }
            }
        } else {
            echo "No se encontraron datos.";
            exit();
        }

        $conn->close();
        ?>

        <!-- Dibuja el gráfico de barras apiladas -->
        <div id="chart_div_barras_apiladas"></div>
        <script type="text/javascript">
            // Función para dibujar el gráfico de barras apiladas
            google.charts.setOnLoadCallback(drawStackedChart);

            function drawStackedChart() {
                // Crear un DataTable para almacenar los datos
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'Mes');
                <?php
                foreach ($subgeneros as $subgenero) {
                    echo "data.addColumn('number', '" . $subgenero . "');";
                }
                ?>

                data.addRows([
                    <?php
                    foreach ($ventas_por_mes_subgenero as $mes => $subgeneros_ventas) {
                        echo "['" . $mes . "', ";
                        foreach ($subgeneros as $subgenero) {
                            $ventas = isset($subgeneros_ventas[$subgenero]) ? $subgeneros_ventas[$subgenero] : 0;
                            echo $ventas . ", ";
                        }
                        echo "],";
                    }
                    ?>
                ]);

                // Opciones del gráfico de barras apiladas
                var options = {
                    title: 'Ventas por Subgénero',
                    width: 800,
                    height: 500,
                    isStacked: true,
                    legend: { position: 'top', maxLines: 3 },
                    vAxis: { minValue: 0 }
                };

                // Instanciar y dibujar el gráfico de barras apiladas
                var chart = new google.visualization.ColumnChart(document.getElementById('chart_div_barras_apiladas'));
                chart.draw(data, options);
            }
        </script>
    </div>

     <!-- Script para la actualización dinámica de la tabla -->
     <script>
        function actualizarTabla() {
            var nVendedores = document.getElementById("nVendedores").value;

            // Petición AJAX para obtener los datos de los vendedores
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Limpiar la tabla actual
                    var cuerpoTabla = document.getElementById("cuerpoTabla");
                    cuerpoTabla.innerHTML = "";

                    // Obtener y mostrar los datos actualizados
                    var datos = JSON.parse(this.responseText);
                    for (var i = 0; i < datos.length; i++) {
                        var posicion = i + 1;
                        var fila = "<tr><td>" + posicion + "</td><td>" + datos[i].nombre_vendedor + "</td><td>" + datos[i].total_ventas + "</td></tr>";
                        cuerpoTabla.innerHTML += fila;
                    }
                }
            };
            xhttp.open("GET", "TOP_VENDEDORES/obtener_top_vendedores.php?n=" + nVendedores, true);
            xhttp.send();
        }

        // Llamar a la función una vez al cargar la página para mostrar los datos iniciales
        actualizarTabla();
    </script>

    
    <!-- JavaScript para el gráfico de Radar -->
    <script>
        // PHP para obtener datos de la base de datos y convertirlos a JSON
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "libreria";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $database);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consulta SQL para obtener los datos de rendimiento de los subgéneros
        $sql = "SELECT s.nombre_subgenero AS subgenero, COUNT(l.ISBN) AS cantidad_libros
                FROM libros l
                JOIN subgenero s ON l.id_subgenero = s.id_subgenero
                GROUP BY l.id_subgenero
                ORDER BY cantidad_libros DESC";

        $result = $conn->query($sql);

        // Array para almacenar los resultados
        $datos = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $datos[] = $row;
            }
        }

        // Cerrar conexión
        $conn->close();

        // Convertir datos a formato JSON
        $json_datos = json_encode($datos);
        echo "var datos = " . $json_datos . ";";
        ?>

        // Preparar datos para el gráfico de radar
        var nombresSubgeneros = [];
        var cantidadLibros = [];

        datos.forEach(function(item) {
            nombresSubgeneros.push(item.subgenero);
            cantidadLibros.push(item.cantidad_libros);
        });

        // Configuración del gráfico de radar
        var ctx = document.getElementById('graficoRadar').getContext('2d');
        var myRadarChart = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: nombresSubgeneros,
                datasets: [{
                    label: 'Cantidad de Libros por Subgénero',
                    data: cantidadLibros,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)', // Color de fondo
                    borderColor: 'rgba(54, 162, 235, 1)', // Color del borde
                    borderWidth: 1
                }]
            },
            options: {
                scale: {
                    ticks: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <!--GRAFICO DE GAUGE -->
    <?php
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $dbname = 'libreria';
    $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

    if ($mysqli->connect_errno)
        die('No se puede conectar: ' . $mysqli->connect_error);

    // Consulta SQL para verificar si hay ventas en el mes actual
    $check_sql = 'SELECT COUNT(*) AS numVentas FROM ventas WHERE DATE_FORMAT(fecha_venta, "%Y-%m") = DATE_FORMAT(CURRENT_DATE, "%Y-%m")';
    $check_resultado = $mysqli->query($check_sql);

    if (!$check_resultado)
        die('No se pudo realizar la consulta: ' . $mysqli->error);

    $check_row = $check_resultado->fetch_assoc();
    $numVentas = $check_row['numVentas'] ?? 0;

    // Si no hay ventas en el mes actual, insertamos datos de ejemplo
    if ($numVentas == 0) {
        $insert_sql = "INSERT INTO ventas (`ISBN`, `id_usuario`, `id_vendedor`, `cantidad_libros`, `fecha_venta`) VALUES
                   ('9780545010221', 1, 1, 10, '2024-06-01 08:00:00'),
                   ('9789561129528', 2, 2, 15, '2024-06-05 12:30:00'),
                   ('9789876123549', 3, 3, 30, '2024-06-10 14:00:00')";
        if (!$mysqli->query($insert_sql))
            die('No se pudo insertar datos de ejemplo: ' . $mysqli->error);
    }

    // Consulta SQL para obtener el total de libros vendidos en el mes actual
    $sql = 'SELECT SUM(cantidad_libros) AS TotalLibrosVendidos FROM ventas WHERE DATE_FORMAT(fecha_venta, "%Y-%m") = DATE_FORMAT(CURRENT_DATE, "%Y-%m")';
    $resultado = $mysqli->query($sql);

    if (!$resultado)
        die('No se pudo realizar la consulta: ' . $mysqli->error);

    $row = $resultado->fetch_assoc();
    $totalLibrosVendidos = $row['TotalLibrosVendidos'] ?? 0;

    $resultado->free();
    $mysqli->close();
?>


<!-- Div para el gráfico de gauge -->
<div id="gauge_div" style="width: 200px; height: 200px; margin: 20px auto;"></div>
<!-- JavaScript para el gráfico de Gauge -->
<script type="text/javascript">
    // Datos PHP convertidos a JavaScript
    var totalLibrosVendidos = <?php echo $totalLibrosVendidos; ?>;

    // Cargar la API de visualización y el paquete 'gauge'
    google.charts.load('current', {'packages':['gauge']});

    // Llamar a la función de dibujo después de cargar Google Charts
    google.charts.setOnLoadCallback(drawGauge);

    // Función para dibujar el gráfico de gauge
    function drawGauge() {
        // Crear los datos para el gráfico de gauge
        var data = google.visualization.arrayToDataTable([
            ['Label', 'Value'],
            ['Libros Vendidos', totalLibrosVendidos]
        ]);

        // Configuración del gráfico de gauge
        var options = {
            width: 200, height: 200,
            greenFrom: 0, greenTo:50,
            redFrom: 75, redTo: 100, // Rango rojo
            yellowFrom: 50, yellowTo: 90, // Rango amarillo
            minorTicks: 5
        };

        // Crear una instancia del gráfico de gauge y dibujarlo en 'gauge_div'
        var chart = new google.visualization.Gauge(document.getElementById('gauge_div'));
        chart.draw(data, options);
    }
</script>

<!--  GRAFICO DE TORTA  -->
<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'libreria';
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if($mysqli->connect_errno) {
    die('No se puede conectar: ' . $mysqli->connect_error);
}

$sql1 = 'SELECT subgenero.nombre_subgenero AS Subgenero, SUM(ventas.cantidad_libros * libros.precio) AS TotalVentas
         FROM libros
         JOIN subgenero ON libros.id_subgenero = subgenero.id_subgenero
         JOIN ventas ON libros.ISBN = ventas.ISBN
         GROUP BY subgenero.nombre_subgenero';

$resultado = $mysqli->query($sql1);

if(!$resultado) {
    die('No se pudo realizar la consulta: ' . $mysqli->error);
}

$datos1 = "";

while($row = $resultado->fetch_assoc()) {
    $datos1 .= "['" . $row['Subgenero'] . "'," . $row['TotalVentas'] . "],";
}

$datos1 = rtrim($datos1,",");

$resultado->free();
$mysqli->close();
?>

<!-- Gráfico de Torta - Ventas por Subgénero -->
<h2 class="titulo-grafico">Gráfico de Torta - Ventas por Subgénero</h2>
<div class="chart-container">
    <div id="chart_div_pie"></div>
    <script type="text/javascript">
        google.charts.setOnLoadCallback(drawPieChart);

        function drawPieChart() {
            var dataPie = new google.visualization.DataTable();
            dataPie.addColumn('string', 'Subgenero');
            dataPie.addColumn('number', 'TotalVentas');
            dataPie.addRows([<?php echo $datos1; ?>]);

            var optionsPie = {
                'title': 'Total de Ventas por Subgénero',
                'width': 800,
                'height': 600
            };

            var chartPie = new google.visualization.PieChart(document.getElementById('chart_div_pie'));
            chartPie.draw(dataPie, optionsPie);
        }
    </script>
</div>



</body>
</html>