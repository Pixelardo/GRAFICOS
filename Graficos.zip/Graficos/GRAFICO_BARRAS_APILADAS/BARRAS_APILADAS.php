<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para obtener las ventas por mes y subgénero
$sql = 'SELECT 
            DATE_FORMAT(ventas.fecha_venta, "%Y-%m") AS Mes, 
            subgenero.nombre_subgenero AS Subgenero, 
            SUM(ventas.cantidad_libros * libros.precio) AS TotalVentas
        FROM 
            ventas
        JOIN 
            libros ON ventas.ISBN = libros.ISBN
        JOIN 
            subgenero ON libros.id_subgenero = subgenero.id_subgenero
        GROUP BY 
            Mes, Subgenero
        ORDER BY 
            Mes, Subgenero';

$result = $conn->query($sql);

if (!$result) {
    die('Consulta fallida: ' . $conn->error);
}

// Arreglos para almacenar los datos
$ventas_por_mes_subgenero = [];
$subgeneros = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $mes = $row['Mes'];
        $subgenero = $row['Subgenero'];
        $totalVentas = (float)$row['TotalVentas'];

        if (!isset($ventas_por_mes_subgenero[$mes])) {
            $ventas_por_mes_subgenero[$mes] = [];
        }

        $ventas_por_mes_subgenero[$mes][$subgenero] = $totalVentas;

        if (!in_array($subgenero, $subgeneros)) {
            $subgeneros[] = $subgenero;
        }
    }
} else {
    echo "No se encontraron datos.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gráfico de Ventas Mensuales por Subgénero</title>
<!-- Incluir Google Charts -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    // Cargar las bibliotecas de visualización de Google Charts
    google.charts.load('current', {'packages':['corechart', 'bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        // Datos para el gráfico de barras apiladas
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Mes');
        <?php foreach ($subgeneros as $subgenero) { ?>
            data.addColumn('number', '<?php echo $subgenero; ?>');
        <?php } ?>
        data.addRows([
            <?php
            foreach ($ventas_por_mes_subgenero as $mes => $subgeneros_ventas) {
                echo "['$mes', ";
                foreach ($subgeneros as $subgenero) {
                    $ventas = isset($subgeneros_ventas[$subgenero]) ? $subgeneros_ventas[$subgenero] : 0;
                    echo "$ventas, ";
                }
                echo "],";
            }
            ?>
        ]);

        var options = {
            title: 'Ventas Mensuales por Subgénero',
            chartArea: {width: '70%', height: '70%'}, // Ajustar el tamaño del área del gráfico
            isStacked: true,
            hAxis: {
                title: 'Ventas ($)',
                minValue: 0,
            },
            vAxis: {
                title: 'Mes'
            }
        };

        var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        chart.draw(data, options);
    }
</script>
</head>
<body>
    <!-- Div que contendrá el gráfico -->
    <div id="chart_div" style="width: 90%; height: 600px;"></div> <!-- Ajustar el tamaño del contenedor -->
</body>
</html>